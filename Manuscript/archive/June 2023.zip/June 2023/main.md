---
title: Comparing Treatments for Amblyopia with a Synaptic Plasticity Model
subtitle: 
author: Brian S. Blais
tags: [bcm, amblyopia,synaptic plasticity]
toc: true
classoption: onecolumn
colorlinks: true
linestretch: 1.5
secnumdepth: 2
lineno: false
implicit_figures: true

csl: /Users/bblais/tex/bib/apalike.csl
bibliography: /Users/bblais/tex/bib/Amblyopia.bib
---

![[0. Preface]]

![[1. Introduction]]

![[2. Methods]]

![[3. Results]]

![[4. Concusions and Discussion]]

# References




