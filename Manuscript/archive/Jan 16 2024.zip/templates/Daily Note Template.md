---
tags: DailyNote 
---

# {{date:YYYY-MM-DD}}  {{time:HH:mm}}


## Questions/tasks 

#todo 

- [ ] task


